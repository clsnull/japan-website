module.exports = {
    apps: [
        {
            name: "japan-website-api",
            script: "npm run start:prod",
        },
    ],
};